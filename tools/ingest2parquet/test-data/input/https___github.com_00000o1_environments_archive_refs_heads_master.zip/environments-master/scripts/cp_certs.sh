#!/usr/bin/env bash

cp -r -L /etc/letsencrypt/live/$1/* $2

